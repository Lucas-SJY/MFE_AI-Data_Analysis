t=5;    % time,unit s
x0=10;  % unit m
v0=15;  % unit m/s
a=-9.81;% unit m/(s^2)
% x is the distace travelled by a ball falling in the air
x=x0+v0.*t+1/2.*a.*(t.^2);