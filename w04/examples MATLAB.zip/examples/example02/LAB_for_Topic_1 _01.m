a=10000;
b=1+0.053;  % annual intreset
c=900000;
i=0;    %year
while a<=c
    a=(a+10000)*b;
    i=i+1;
end