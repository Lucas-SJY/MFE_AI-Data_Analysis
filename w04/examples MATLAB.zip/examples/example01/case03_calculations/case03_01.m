y=function_log(-2)
y=function_log(0)
% y=function_log(1) x!=1
%y=function_log(2)  x!=2

