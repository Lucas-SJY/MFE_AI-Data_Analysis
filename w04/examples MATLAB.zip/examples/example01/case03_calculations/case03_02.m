z1=funxy(4,5)
z2=funxy(4,-5)
z3=funxy(-4,5)
z4=funxy(-4,-5)