function [y]=function_log(x)
y=log(1/(1-x))
end