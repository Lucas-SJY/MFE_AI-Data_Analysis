x=distance(10,15,5,-9.81)

