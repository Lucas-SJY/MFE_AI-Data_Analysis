function [x]=distance(x_0,v_0,t,a)
x=x_0+v_0.*t+1/2*a.*t.*t
end

