function [z]=SGA_FITNESS_function(x,y)
z=(sin(x)./x).*(sin(y)./y)
end