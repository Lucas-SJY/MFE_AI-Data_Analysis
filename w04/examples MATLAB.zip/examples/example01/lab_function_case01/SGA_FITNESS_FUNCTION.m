function [y]=SGA_FITNESS_FUNCTION(x)
y=x.*sin(10*pi*x)+2.0
end
