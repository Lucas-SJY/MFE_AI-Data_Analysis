function [y]=f(x)
y=(668.06./x).*(1-exp(-0.146843*x))-40
end
